package com.example.textdetection;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.service.voice.VoiceInteractionSession;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.IOException;







import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;








public class MainActivity extends AppCompatActivity {
    Button button_capture,button_copy,button_excel;
    TextView textview_data;
    Bitmap bitmap;
    private static final int REQUEST_CAMERA_CODE = 100;
    int count;
    private SharedPreferences preference;
    private SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button_capture = findViewById(R.id.button_capture);
        button_copy = findViewById(R.id.button_copy);
        button_excel = findViewById(R.id.button_excel);
        textview_data = findViewById(R.id.text_data);


        //プリファレンスの準備
        preference = getSharedPreferences("Preference Name", MODE_PRIVATE);
        editor = preference.edit();

        if (preference.getBoolean("Launched", false)==false) {
            //初回起動時の処理
            count=1;

            //プリファレンスの書き変え
            editor.putBoolean("Launched", true);
            editor.commit();
        }




        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.CAMERA
            }, REQUEST_CAMERA_CODE);
        }
        button_capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity().setGuidelines(CropImageView.Guidelines.ON).start(MainActivity.this);
            }
        });
        button_copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String scanned_text= textview_data.getText().toString();
                copyToClipBoard(scanned_text);
            }
            });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),resultUri);
                    getTextFromImage(bitmap);
                }
                catch (IOException e)

                {
                    e.printStackTrace();
                }
            }
        }
    }














public void onExcelClick(View v) {
    File file;

    String scanned_text= textview_data.getText().toString();

    Workbook wb = new HSSFWorkbook();
    Cell cell = null;
    CellStyle cellStyle = wb.createCellStyle();
   // cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
    cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);


    //Now we are creating sheet
    Sheet sheet = null;
    sheet = wb.createSheet("Name of sheet");
    //Now column and row

    Row row = sheet.createRow(0);
    cell = row.createCell(0);
    cell.setCellValue(scanned_text);
    cell.setCellStyle(cellStyle);

    sheet.setColumnWidth(0, (10 * 200));

    SharedPreferences data = getSharedPreferences("Data", MODE_PRIVATE);
    SharedPreferences.Editor editor = data.edit();



if(count==1){


    file = new File(getExternalFilesDir(null), "plik1.xls");

        count++;
        editor.putInt("DataInt", count);
        editor.commit();

}else{
  count = data.getInt("DataInt", count);

 
   file = new File(getExternalFilesDir(null), "plik"+count+".xls");
        count++;
   editor.putInt("DataInt", count);
    editor.commit();


}










    FileOutputStream outputStream = null;


    try {
        outputStream = new FileOutputStream(file);
        wb.write(outputStream);
        Toast.makeText(getApplicationContext(), "OK", Toast.LENGTH_LONG).show();
    } catch (java.io.IOException e) {

        e.printStackTrace();

        Toast.makeText(getApplicationContext(), "NO OK", Toast.LENGTH_LONG).show();
        try {
            outputStream.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}





    private void getTextFromImage(Bitmap bitmap)
    {
        TextRecognizer recognizer = new TextRecognizer.Builder(this).build();
        if (!recognizer.isOperational())
        {
            Toast.makeText(MainActivity.this,"Error Occurred!!",Toast.LENGTH_SHORT).show();
        }
        else
        {
            Frame frame = new Frame.Builder().setBitmap(bitmap).build();
            SparseArray<TextBlock> textBlockSparseArray= recognizer.detect(frame);
            StringBuilder stringBuilder = new StringBuilder();
            for (int i=0; i<textBlockSparseArray.size();i++) {
                TextBlock textBlock = textBlockSparseArray.valueAt(i);
                stringBuilder.append(textBlock.getValue());
                stringBuilder.append("\n");
            }
            textview_data.setText(stringBuilder.toString());
            button_capture.setText("Retake");
            button_copy.setVisibility(View.VISIBLE);
        }
    }
    private void copyToClipBoard(String text)
    {
        ClipboardManager clipBoard= (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Copied data",text);
        clipBoard.setPrimaryClip(clip);
        Toast.makeText(MainActivity.this,"Copied to Clipboard!",Toast.LENGTH_SHORT).show();
    }
}